clear all; close all; clc;
%% *MATLAB-Make-it-look-good-Meetup-Graphics-and-Visualisation-Extension-21.05.18*
% Contact: Alicia Takbash
% Facebook: MATLAB @ Unimelb
% Twitter: @Alicia_Tak
% Email: alicia.resplat@gmail.com
 

% Based on Make it Look Good on MATLAB - The Visualization Extension Meetup

% Datasets obtained from: "Teachers and Professors". Published online at 
% OurWorldInData.org. Retrieved from: 'https://ourworldindata.org/teachers-and-professors' 
% [Online Resource]

%% 1. Importing Data into MATLAB
%% 1.1 Table Form
% We are going to use the readtable function to transfer our data into MATLAB 
%% Task 1 - import the 'number-of-teachers-across-education-levels.csv' file




%% You can access specific variables in the table using the dot (.) notation. 
%% Task 2 - access the variable 'Entity' using the dot notation and save it 
% under 'Entity'




%% We want to access the 'World'-category within the Entity data. 
%% Task 3 - use 'find' and 'strcmp' function to find the data for the 'World'-category 
% and assign the data to the variable 'indx_W'



% strcmp fuction compares 'data.Entity' and 'World' and returns 1 if the two are 
% identical and 0 otherwise.
%%  Now we can find the corresponding data of all levels of education using 
% the index (indx_W).
%% Task 4 - Try to apply the index to find the 'World' data across all levels 
% of education

% Years


% Pre-primary education 'P_P'


% Primary education 'P'


% Lower secondary education 'L_S'


% Upper secondary education 'U_S'


% Tertiary education 'T'



%% 1.1. Working around the NaN values
% If you want to do further calculations, e.g. calculating cumulative sum across 
% all levels of education you should work around the NaNs. 
%% Task 5 - Try to locate the NaNs with 'isnan' function and set these to 0








%% 1.2 Discretizing the data
% To avoid repeated values in the variable 'Years' within the world category, 
% we determine bin intervals that seperates each year category from 1970 to 2014 
% (45 years).
%% Task 6 - Create bin intervals with 'linspace' function (create 45 bins / 46 levels)



% Use the discretize function to place each value into a bin



%% Task 7 - use the 'unique'  fuction to check if there are repeated values 
% (of years) in the variable 'Years'




% Index a returns the same values as in 'Years_Bins' but with no
% repetitions and c is the index of each value in the bins
%% 2. Stacked area plot 
% An area graph is used to visualize elements in a vector or matrix as one or 
% more curves and fills the area beneath each curve. In case of matrix, the curves 
% are stacked showing the relative contribution of each row element to the total 
% height of the curve at each x interval.

%% Task 8 -  Create a matrix 'y' of the data of all levels of education for the stacked area plot




%% 2.1 Creating the stack area plot 
% 'area' function plots each column in matrix y as a separate curve and stacks 
% the curves. With 'h' (object handle) we can access graphic object properties.
%% Task 9 - Create an object handle for the area plot of matrix 'y' 
% Create the area plot using the area function
% Return the five area objects in array h



%% Task 10 - Create a new object handle with additional properties 


% display the y-axis value without exponent 
% use the face color 'flat'
%% Task 11 - Set x-axis limits, ticks positions and ticks lables

% set x-axis limits


% set x-axis ticks position


% set x-axis ticks lables



%% 2.2 Access and modify the properties of the plot 
% Change the face color to custom colors using the object handle.
%% Task 12 - Use the object handle to change the face color individually for 
% each area
% Use dot notation to refer to a particular object and property




%% Task 13 -  Use 'set' function to access the property for an array of objects 
% (i.e. all areas) and set the line width to 2 and back to 1, and use a dotted 
% line style



%% Task 14 - Add a grid to the plot 



%% To be able to see the grid in the background, use the object handle 'h' 
% to set the face transparency (Alpha)
%% Task 15 - Set the face color transparency (Alpha = 0.5)







%% Task 15 - Add title and axis lables to the plot




%% Task 16 - Add an additional y-axis to the right site to lable each area
% as a legend



%% Task 17 - Set y-axis properties (right) to obtain a legend for the individual 
% areas




%% The last created axis or chart for the current figure can be accessed 
% using ax = gca. We can use ax. to access and modify properties of the y axis 
% on the right.
%% Task 18 -  use ax. to change the color of y-axis lables (right) 

