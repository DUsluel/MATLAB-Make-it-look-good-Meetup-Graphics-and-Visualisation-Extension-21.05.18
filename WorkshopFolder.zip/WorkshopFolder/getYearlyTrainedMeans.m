function [AlgYearGrp_trainedTeachShareval,YearlytrainedTeachShare_Aust] = getYearlyTrainedMeans(countryName,data)

    [EntityGrp_trainedTeachSharenum, EntityGrp_trainedTeachShareval] =findgroups(data.Entity);
    if nnz(find(categorical(EntityGrp_trainedTeachShareval)==countryName)) == 0
        disp('Country is not in list')
        AlgYearGrp_trainedTeachShareval=[];
        YearlytrainedTeachShare_Aust = [];
        return;
    end
    Alg_idx = (EntityGrp_trainedTeachSharenum==find(categorical(EntityGrp_trainedTeachShareval)==countryName));

    % Get groups of years
    [AlgYearGrp_trainedTeachSharenum, AlgYearGrp_trainedTeachShareval] =findgroups(data.Year(Alg_idx));

    % use splitpply to take the mean pupil per qualified teacher ratio for each year group across only 
    YearlytrainedTeachShare_Aust = splitapply(@nanmean,data.PercentageOfTeachersInPrimaryEducationWhoAreTrained_BothSexes__(Alg_idx),AlgYearGrp_trainedTeachSharenum);
end

