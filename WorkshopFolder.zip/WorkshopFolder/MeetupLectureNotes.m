clear; close all;clc;
%% *MATLAB DATA Visualization Extension Meetup*
% Based on the Data Processing and Visualization Course
% 
% Datasets obtained from: "Teachers and Professors". Published online at 
% OurWorldInData.org. Retrieved from: 'https://ourworldindata.org/teachers-and-professors' 
% [Online Resource]
% 
% Social Media Channels:
% 
% > Facebook: MATLAB@Unimelb
% 
% > Twitter: @Alicia_Tak
% 
%            @DUsluel
%% Introduction
% In this meetup we will go through data visualization techniques, tips and 
% tricks including simple plots all the way to higher dimensional figures. These 
% methods will be useful for turning your findings into presentable and understandable 
% representations.
% 
% Similar to the previous workshop, we will be analyzing a real dataset on 
% teacher quality and quantities around the world (citation given above), but 
% you will be able to apply the methods easily to your own data.
% 
% > More datasets can be found on the GitHub repository at: <https://github.com/awesomedata/awesome-public-datasets#machinelearning 
% https://github.com/awesomedata/awesome-public-datasets#machinelearning>
%% 1. Importing Data:
%Task 1-Import the datasets you want to use with different variable names into your workspace using the readtable function
%Quality datasets
pupPerQT_GDP = readtable('Data\Quality\pupils-per-qualified-teacher-vs-gdp-per-capita.csv');
actualTeachingT = readtable('Data\Quality\actual-teaching-time-as-share-of-scheduled-teaching-time.csv');
trainedTeachShare = readtable('Data\Quality\share-of-teachers-in-primary-education-who-are-trained.csv');
%Quantity datasets
numTeachAcrossLvls = readtable("Data\Quantity\number-of-teachers-across-education-levels.csv");
pupTeachRatio_primEd = readtable('Data\Quantity\pupil-teacher-ratio-for-primary-education-by-country.csv');
FemalePrimEdTeachShare = readtable('Data\Quantity\share-of-primary-school-teachers-who-are-female.csv');
%% 2. MATLAB Graphics:
% Task 1-obtain the mean values of the pupil per qualified ratio in every group and omit the NaN values for Algeria
% Task 2-group the data into unique years by using findgroups across years on only Algerian data
% Task 3-Apply the mean function while omitting NaN values to calculate yearly mean values
% Task 4-Create a simple scatter graph showing the mean trained teacher ratio for Algeria
%% You can use the custom function getYearlyTrainedMeans to calculate the same values for other countries that are on the list
%% 2.1: Objects and Properties:
% Task1-Play with the properties of the line graphics object created by the plot command by adding name-value pairs that modify the object properties:
% Task2-create a scatter plot using the same x and y data
%% 2.2: Graphics Functions:
% The functions provided by MATLAB allow the change of visualization properties without the need for adding extra parameters in the first function and can be applied afterwards

%% 3. Modifying Graphics Object Properties:
clear; close all; clc;
[x,y] = getYearlyTrainedMeans('Bahamas',trainedTeachShare);
%% 3.1: Accessign Graphics Objects:
% Task 1-Create a figure and make a handle
% Task 2-Plot one of the above examples as a line plot and obtain a handle for the plot
% Task 3 - Get the handle for the current axes object and observe properties
% Task 4 - Create a scatter graph using x & y and save the graphics objects to a handle
%% 3.2: Obtaining and Modifying Properties:
% Task 1- play with the axis properties of the plot by using the dot notation
% Task 2-Check the Documentation for plot properties to learn which property allows to change the X data of a plot and change it to observe the result
% Task 3-Lets create our plot and place a smaller plot into the plot by playing with the axes location and axis limits
%% 3.3: Object Hieararchy:
% Task 1-Use the Children property of the figure to get the axes
% Task 2-Seperately obtain the two different axes objects
% Task 3-Use the Children property of the axes to get the plot in each
% Task 4-Observe the type of each plot using 'Type'